import { watchFile, unwatchFile } from "fs";
import { fileURLToPath } from "url";
import chalk from "chalk";

// Owner
global.owner = [["62895617813070", "Rikky-MD", true]];
global.mods = [];
global.prems = [];
// Info
global.nomorwa = "62895617813070";
global.namebot = "Future - Bot";
global.stickpack = "Future - Bot";
global.stickauth = "PX - Team";
// Link Sosmed
global.sig = "https://instagram.com/Rikkymd";
global.sgh = "https://github.com/Rikkymd";
global.pdana = "0822-1162-6509";
// Info Wait
global.wait = "*_In progress, please wait..._*";
global.eror = "_Error Detected, Report it to the owner!._ ";
//_______________________ [ DOC ] _______________________//
global.doc1 =
  "application/vnd.openxmlformats-officedocument.presentationml.presentation";
global.doc2 =
  "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
global.doc3 =
  "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
global.doc4 = "application/zip";
global.doc5 = "application/pdf";
global.doc6 = "application/vnd.android.package-archive";

//____________________ [ FAKE SIZE ] ____________________//
global.jumlha = "999";
global.jumhal = "100000000000000";
global.jumlah = "1000000000";
global.multiplier = 100;
//____________________ [ SYMBOL ] ____________________//
global.htjava = `•`;
global.htka = `]━━━━━━`;
global.htki = `━━━━━━[`;
global.tm1 = `┌───═[`;
global.tm2 = `]═──▸`;
global.tm3 = `┴│▸`;
global.tm4 = `⬡│▸`;
global.tm5 = `┬│▸`;
global.tm6 = `└───────────────···▸`;
//____________________ [ RANDOM THUMB ] ____________________//
global.hprinz = [
  "https://telegra.ph/file/eee054ee64d793687eba0.jpg",
]

/* Web Api */
global.APIs = {
    rose: "https://api.itsrose.life",
    prinz: "http://api.royalprinz.my.id"
}

/* ApiKeys */
global.APIKeys = {
    "https://api.itsrose.life": "Rk-PrinzKey",
    "https://api.royalprinz.my.id": "Px-KeyPrinzOfc"
}

global.rose = "Rk-PrinzKey"
global.prinzkey = "Px-PrinzKey"
global.openaikey = "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"

/* FAKE QUOTED */
global.fkontak = {
   key: {
       participant: '0@s.whatsapp.net',
       remoteJid: 'status@broadcast'
   },
   message: {
       contactMessage: {
           displayName: stickauth,
           vcard: `BEGIN:VCARD\nVERSION:3.0\nN:XL;${stickauth},;;;\nFN:${stickauth},\nitem1.TEL;waid=0:0\nitem1.X-ABLabell:Ponsel\nEND:VCARD`,
           jpegThumbnail: './src/avatar_contact.png',
           thumbnail: './src/avatar_contact.png',
           sendEphemeral: true
       }
   }
}

/* REDEEM CODE */
global.validOTPs = [
    "239210"
  ]

/* Randomizer */
function pickRandom(list) {
    return list[Math.floor(Math.random() * list.length)]
}

let file = fileURLToPath(import.meta.url);
watchFile(file, () => {
  unwatchFile(file);
  console.log(chalk.redBright("Update 'config.js'"));
});