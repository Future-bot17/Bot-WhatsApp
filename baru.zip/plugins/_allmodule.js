const { _makeWaSocket, extractImageThumb, generateWAMessage, makeWALegacySocket, proto, jidDecode, getDevice, waChatKey, Presence, ProxyAgent, getContentType, getBinaryNodeChild, processTime, downloadContentFromMessage, makeInMemoryStore, extractMessageContent, prepareWAMessageMedia, generateWAMessageFromContent, generateWAMessageContent, MessageType, MessageOptions, Mimetype, WALocationMessage, WAMessageStubType, WAMessageProto, ReconnectMode, ChatModification, GroupSettingChange, WA_MESSAGE_STUB_TYPES, WA_DEAFULT_EPHEMERAL, getAggregateVotesInPollMessage } = (await import('@whiskeysockets/baileys')).default
import { createRequire } from 'module';
import axios from 'axios'
//import util from 'util'
//import { fileURLToPath, URL, pathToFileURL } from 'url'
import fs from 'fs'
//import store from '../lib/store.js'
import PhoneNumber from 'awesome-phonenumber'
//import PDFDocument from 'pdfkit'
import FormData from 'form-data'
//import { performance } from "perf_hooks"
//import { randomBytes } from 'crypto';
import fetch from 'node-fetch'
//import cron from 'node-cron'
import chalk  from 'chalk'
import path from 'path'
import ffmpeg from 'fluent-ffmpeg'
import * as cheerio from 'cheerio'
//import didyoumean from 'didyoumean'
import jsdom from 'jsdom'
import moment from 'moment-timezone'
import pino from 'pino'
import similarity from 'similarity'
//import ytdl from 'ytdl-core'
import pkg from 'yt-search'
import jimp from 'jimp'
//import jsobfus from 'javascript-obfuscator'
import { fileTypeFromBuffer } from 'file-type'
//import { exec, spawn, execSync } from 'child_process'
//import { tmpFiles, pomf } from '../scraper/tmpUpload.js'
import {
  webp2mp4, 
  webp2png
} from '../lib/webp2mp4.js'

let handler = m => m
handler.all = async function (m) {
const { yts, search } = pkg
global.axios = axios
global.fetch = fetch
global.fs = fs
//global.store = store
global.path = path
//global.util = util
//global.URL = URL
//global.exec = exec
global.proto = proto
global.chalk = chalk
//global.cron = cron
//global.spawn = spawn
global.cheerio = cheerio
global.jimp = jimp
//global.jsdom = jsdom
//global.jsobfus = jsobfus
global.moment = moment
global.pino = pino
//global.ytdl = ytdl
global.yts = yts
//global.pathToFileURL = pathToFileURL
//global.fileURLToPath = fileURLToPath
global.search = search
//global.performance = performance
//global.execSync = execSync
global.similarity = similarity
//global.didyoumean = didyoumean
//global.uploadImage = pomf
global.waChatKey = waChatKey
global.getDevice = getDevice
global.jidDecode = jidDecode
//global.randomBytes = randomBytes
global.fileTypeFromBuffer = fileTypeFromBuffer
global.getBinaryNodeChild = getBinaryNodeChild
global.getContentType = getContentType
global.rocessTime = processTime
global.ffmpeg = ffmpeg
global.Presence = Presence
global.FormData = FormData
global.Mimetype = Mimetype
global.ProxyAgent = ProxyAgent
global.MessageType = MessageType
//global.PDFDocument = PDFDocument
global.PhoneNumber = PhoneNumber
global.ReconnectMode = ReconnectMode
global.MessageOptions = MessageOptions
global.ChatModification = ChatModification
global.WAMessageProto = WAMessageProto
global.GroupSettingChange = GroupSettingChange
global.WALocationMessage = WALocationMessage
global.WAMessageStubType = WAMessageStubType
global.extractImageThumb = extractImageThumb
global._makeWaSocket = _makeWaSocket
global.makeInMemoryStore = makeInMemoryStore
global.generateWAMessage = generateWAMessage
global.makeWALegacySocket = makeWALegacySocket
global.extractMessageContent = extractMessageContent
global.prepareWAMessageMedia = prepareWAMessageMedia
global.WA_DEAFULT_EPHEMERAL = WA_DEAFULT_EPHEMERAL
global.generateWAMessageContent = generateWAMessageContent
global.WA_MESSAGE_STUB_TYPES = WA_MESSAGE_STUB_TYPES
global.downloadContentFromMessage = downloadContentFromMessage
global.getAggregateVotesInPollMessage = getAggregateVotesInPollMessage
global.generateWAMessageFromContent = generateWAMessageFromContent
global.require = createRequire(import.meta.url)

}
export default handler