import { indown } from "../scrape/Instagram.js";

const handler = async (m, { conn, text, args, usedPrefix, command }) => {
  await m.reply(wait)

  try {
    if (!text) {
      return m.reply(
        `*PERMINTAAN ERROR! CONTOH:*\n> .${command} https://www.instagram.com/reel/C9Y4yNDR9FY/?igsh=Zmo5bDd3dTl6MXQ0`
      );
    }

    const mediaLinks = await indown(text);
    if (mediaLinks.length === 0) {
      return m.reply("Tidak ada media ditemukan.");
    }

    for (const media of mediaLinks) {
      const { type, href, alternative } = media;

      try {
        if (type === "video") {
          // Mencoba mengirimkan link video
          await conn.sendMessage(m.chat, { video: { url: href }, caption: "Video dari Instagram" });
        } else if (type === "image") {
          // Mencoba mengirimkan link gambar
          await conn.sendMessage(m.chat, { image: { url: href }, caption: "Gambar dari Instagram" });
        }
      } catch (error) {
        console.error("Gagal mengirimkan link media utama, mencoba alternatif:", error);
        
        // Jika pengiriman link utama gagal, kirim link alternatif
        if (type === "video") {
          await conn.sendMessage(m.chat, { video: { url: alternative }, caption: "Video dari Instagram (alternatif)" });
        } else if (type === "image") {
          await conn.sendMessage(m.chat, { image: { url: alternative }, caption: "Gambar dari Instagram (alternatif)" });
        }
      }
    }
  } catch (error) {
    console.error("Kesalahan pada handler:", error);
    m.reply("Terjadi kesalahan saat memproses permintaan Anda.");
  }
};

handler.help = ["ig *[link/query]*"];
handler.tags = ["download"];
handler.command = /^(ig|igdl)$/i;

export default handler