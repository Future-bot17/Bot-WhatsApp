/*
<> *AIO2*<>
scrape by https://whatsapp.com/channel/0029VaiVeWA8vd1HMUcb6k2S/114
Source: https://whatsapp.com/channel/0029VaJYWMb7oQhareT7F40V
  "aku janji jika hapus watermark ini maka aku rela miskin hingga 7 turunan"
*/
import axios from 'axios';
import { JSDOM } from 'jsdom';

class AioDown {
    constructor() {
        this.url = 'https://aiodown.com/wp-json/aio-dl/video-data/';
        this.headers = {
            'accept': '*/*',
            'content-type': 'application/x-www-form-urlencoded',
            'origin': 'https://aiodown.com',
            'referer': 'https://aiodown.com/',
            'user-agent': 'Postify/1.0.0',
            'X-Forwarded-For': Array(4).fill(0).map(() => Math.floor(Math.random() * 256)).join('.'),
        };
        this.cookies = '';
    }

    async fetchToken() {
        try {
            const response = await axios.get('https://aiodown.com');
            const dom = new JSDOM(response.data);
            const tokenElement = dom.window.document.getElementById('token');
            if (tokenElement) {
                return tokenElement.value;
            } else {
                throw new Error('Token tidak ditemukan 😂');
            }
        } catch (error) {
            console.error('Error fetchToken:', error);
            throw error;
        }
    }

    bypassHash(url, additional) {
        return btoa(url) + (url.length + 1000) + btoa(additional);
    }

    async fetch(videoUrl) {
        const maxRetries = 5;
        let retryCount = 0;

        while (retryCount < maxRetries) {
            try {
                const token = await this.fetchToken();
                const hash = this.bypassHash(videoUrl, 'aio-dl');

                const response = await axios.post(this.url, new URLSearchParams({
                    url: videoUrl,
                    token: token,
                    hash: hash,
                }), {
                    headers: {
                        ...this.headers,
                        'cookie': this.cookies,
                    },
                });

                const setKukis = response.headers['set-cookie'];
                if (setKukis) {
                    this.cookies = setKukis.join('; ');
                }

                return response.data;
            } catch (error) {
                if (error.response && error.response.data && error.response.data.error && error.response.data.error.includes("Rate limit exceeded")) {
                    console.log(`Limit request API habis, coba lagi... 😂`);
                    retryCount++;
                } else {
                    console.error('Error fetch:', error.response ? error.response.data : error.message);
                    throw error;
                }
            }
        }

        throw new Error('Terlalu banyak request 😂');
    }

    selectQuality(medias, qualityNa) {
        const media = medias.find(media => media.quality === qualityNa);
        return media ? media.url : null;
    }

    async getLinks(videoUrl, qualityNa = '128kbps') {
        const data = await this.fetch(videoUrl);
        console.log('Data:', data);

        const mediaUrls = data.medias.map(media => ({
            quality: media.quality,
            url: media.url,
        }));

        const links = this.selectQuality(mediaUrls, qualityNa);
        return { mediaUrls, links };
    }
}

let handler = async (m, { conn, text }) => {
    if (!text) throw 'Masukkan URL video yang ingin didownload!';

    try {
        const aioDown = new AioDown();
        const { mediaUrls, links } = await aioDown.getLinks(text);

        if (links) {
            await conn.sendMessage(m.chat, { audio: { url: links }, mimetype: 'audio/mpeg', ptt: false, quoted: m })
        } else {
            m.reply('Gagal mendapatkan link audio anda.');
        }
    } catch (error) {
        console.error(error);
        m.reply('Terjadi kesalahan saat mencoba mengambil audio.');
    }
};

handler.help = ['ytmp3 <url>'];
handler.tags = ['download'];
handler.command = /^ytmp3$/i;

export default handler;

/*
scrape by https://whatsapp.com/channel/0029VaiVeWA8vd1HMUcb6k2S/114
Source: https://whatsapp.com/channel/0029VaJYWMb7oQhareT7F40V
  "aku janji jika hapus watermark ini maka aku rela miskin hingga 7 turunan"
*/