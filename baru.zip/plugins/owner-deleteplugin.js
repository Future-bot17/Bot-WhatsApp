import { readdirSync, unlinkSync, existsSync } from "fs";

const handler = async (
    m,
    { conn, command, usedPrefix: _p, __dirname, args, isROwner, text }
) => {
    if (!isROwner) return;
    const ar = Object.keys(plugins);
    const ar1 = ar.map(v => v.replace(".js", ""));
    if (!text)
        throw `Masukkan nama Pluginnya!\n\nExample: ${_p + command} menu`;
    const filename = `plugins/${text}.js`;
    if (!existsSync(filename))
        throw `'/home/container/plugins/${args[0]}.js' not found!\n\n${ar1
            .map(v => v)
            .join("\n")
            .trim()}`;
    unlinkSync(filename);
    m.reply(`Sukses menghapus 'plugins/${args[0]}.js'`);
};

handler.help = ["deleteplugin"];
handler.tags = ["owner"];
handler.command = ["deleteplugin", "dp"];
handler.rowner = true;

export default handler;