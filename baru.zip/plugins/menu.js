/* Coded By RIKKT-MD */
import { xpRange } from "../lib/levelling.js";
import moment from "moment-timezone";
import os from "os";
import fs from "fs";

const defaultMenu = {
  before: `*Hi %name, %ucapan 👋*
------------------------------------
 *Balance:* %moneyPxr
 *Role:* %role
 *Device:* %device
------------------------------------
 *Clock:*  %wib
 *Day:*  %week
 *Date:*  %date
------------------------------------
 *Kategori Menu*
------------------------------------
%readmore`.trimStart(),
  header: "*[ %category ]*",
  body: ` %cmd`,
  footer: "© FUTURE-MD",
  after: `© FUTURE-MD`,
};

const more = String.fromCharCode(8206);
const readMore = more.repeat(4001);

function ucapan() {
  const time = moment.tz("Asia/Jakarta").format("HH");
  if (time >= 4 && time < 10) return "Pagi";
  if (time >= 10 && time < 15) return "Siang";
  if (time >= 15 && time < 18) return "Sore";
  return "Malam";
}

let device;

let handler = async (m, { conn, usedPrefix: _p, args }) => {
  const user = global.db.data.users[m.sender];
  const userTotal = Object.keys(global.db.data.users).length;
  const { name, money, limit, glimit, exp, level, role } = user;

  if (m.sender === "62895617813070@s.whatsapp.net") {
    device = "iOS";
  } else {
    device = (await Functs.baileys.getDevice(m.key.id));
  }

  let pluginsArray = Object.entries(global.plugins);
  const excludedTags = new Set(["shop", "owner", "advanced", "store", "main"]);
  let tagsMap = {};

  pluginsArray.forEach(([key, plugin]) => {
    if (!plugin || !Array.isArray(plugin.tags)) {
      plugin.tags = [];
    }
    plugin.tags.forEach(tag => {
      if (!excludedTags.has(tag)) {
        if (!tagsMap[tag]) {
          tagsMap[tag] = [];
        }
        tagsMap[tag].push(plugin);
      }
    });
  });

  let wib = moment.tz("Asia/Jakarta").format("HH:mm:ss");
  let week = moment().format('dddd');
  let date = moment().format('DD/MM/YYYY');

  let text = defaultMenu.before;

  let replace = {
    "%": "%",
    me: conn.getName(conn.user.jid),
    wib,
    _p,
    week,
    device,
    date,
    userTotal,
    name,
    money,
    limit,
    glimit,
    exp,
    level, 
    role,
    readmore: readMore,
    ucapan: ucapan(),
  };

  text = text.replace(
    new RegExp(
      `%(${Object.keys(replace).sort((a, b) => b.length - a.length)
        .join`|`})`,
      "g"
    ),
    (_, name) => "" + (replace[name] || "")
  );

  if (args.length === 0) {
    const tags = Object.keys(tagsMap).sort();
    text += `\n**~~~~~~~**\n`;
    tags.forEach(tag => {
      text += `- ${_p}menu ${tag}\n`;
    });
  } else {
    const userTag = args[0].toLowerCase();
    const pluginsWithMatchingTag = tagsMap[userTag] || [];

    if (pluginsWithMatchingTag.length === 0) {
      return conn.reply(
        m.chat,
        `Tidak ada perintah yang terkait dengan tag *${userTag}*.`,
        m
      );
    }

    text += `\n*${userTag.charAt(0).toUpperCase() + userTag.slice(1)}*\n\n`;
    pluginsWithMatchingTag.forEach(plugin => {
      const command = Array.isArray(plugin.help) ? plugin.help[0] : plugin.help;
      text += `- ${_p}${command}\n`;
    });
  }

  text += "\n\n" + defaultMenu.footer;

  const quotedMsg = await conn.reply(m.chat, text.trim(), '', {
    contextInfo: {
      isForwarded: true,
      forwardingScore: 5,
      forwardedNewsletterMessageInfo: {
        newsletterJid: '120363315314251898@newsletter',
        newsletterName: "Future - Bot",
      },
      externalAdReply: {
        renderLargerThumbnail: true,
        mediaType: 1,
        thumbnail: (await conn.getFile("https://telegra.ph/file/eee054ee64d793687eba0.jpg")).data,
        sourceUrl: "https://whatsapp.com/channel/0029Vaimvm3F6sn42dRLW81n",
        title: "Powered By " + stickauth,
        body: "Selamat menikmati fitur kami!",
      }
    }
  });
};

handler.help = ["menu"];
handler.tags = ["main"];
handler.command = /^(menu)$/i;
handler.register = false;

export default handler;