import fetch from 'node-fetch'

let handler = async (m, { conn, text, usedPrefix, command }) => {
    if (!text) throw `*• Contoh:* ${usedPrefix + command} Nakano handler`
    react('⏳')

    try {
        // Upaya pertama untuk mengambil data dari Pinterest
        let query = text.split(' ').join('+')
        let res = await fetch(`https://www.pinterest.com/resource/BaseSearchResource/get/?source_url=%2Fsearch%2Fpins%2F%3Fq%3D${query}&data=%7B%22options%22%3A%7B%22isPrefetch%22%3Afalse%2C%22query%22%3A%22${query}%22%2C%22scope%22%3A%22pins%22%2C%22no_fetch_context_on_resource%22%3Afalse%7D%2C%22context%22%3A%7B%7D%7D&_=1619980301559`)

        if (!res.ok) throw new Error('Gagal mengambil data dari Pinterest')

        let json = await res.json()
        let data = json.resource_response.data.results

        if (!data.length) throw new Error(`Query "${text}" tidak ditemukan :/`)

        let images = data.map(item => item.images.orig.url)
        let randomImage = images[Math.floor(Math.random() * images.length)]

        await conn.sendButton(m.chat, `*[  P I N T E R E S T ]*\n\nHasil Dari: *${text}*`, namebot, randomImage, [
            [`ɴᴇxᴛ ${text}`, `.pin ${text}`]
        ], m)
    } catch (error) {
        // Jika upaya pertama gagal, coba pendekatan kedua
        m.react('⏳')
        try {
            let bubub = await fetch(`https://api.ssateam.my.id/api/pinterest?query=${text}`).json()
            let u = bubub.data.response

            await conn.sendButton(m.chat, `*[  P I N T E R E S T ]*\n\nHasil Dari: *${text}*`, namebot, u, [
                [`ɴᴇxᴛ ${text}`, `.pin ${text}`]
            ], m)
            react('✅')
        } catch (e) {
            react('❌')
            console.log(e)
            throw new Error('Kesalahan saat mengambil data dari sumber cadangan.')
        }
    }
}

handler.help = ['pinterest <pencarian>']
handler.tags = ['download']
handler.command = /^pin(terest)?$/i
handler.diamond = true

export default handler