let handler = async (m, { conn, text }) => {
    if (!text) return conn.reply(m.chat, 'Harap Masukan Teks yang akan direpeat!', m)
    
    let repeatCount = text.match(/\d+/) || [1]
    let repeatedText = text.replace(/\d+/, '').trim()

    let repeatedMessage = ''
    for (let i = 0; i < repeatCount; i++) {
        repeatedMessage += `${repeatedText}\n`
    }

    conn.reply(m.chat, repeatedMessage.trim(), m)
}
handler.help = ['repeat <teks> <count>']
handler.tags = ['tools']
handler.command = /^(repeat|ulang)$/i
handler.owner = true
handler.mods = false
handler.premium = true
handler.group = false
handler.limit = true
handler.private = false

handler.admin = false
handler.botAdmin = false

handler.fail = null
handler.limit = true

export default handler