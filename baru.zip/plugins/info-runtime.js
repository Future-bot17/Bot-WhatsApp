import { createCanvas, loadImage } from 'canvas';

let handler = async (m, { conn }) => {
    // Menghitung waktu aktif bot
    const uptime = process.uptime() * 1000; // Mengambil uptime dalam detik dan mengubahnya menjadi milidetik
    const muptime = clockString(uptime);
    
    const jam = waktu(uptime); // Menggunakan uptime untuk waktu

    // Load the background image
    const background = await loadImage('https://telegra.ph/file/c372b02593dff45b4b7ac.jpg');
    
    // Create a canvas and get the context
    const canvas = createCanvas(background.width, background.height);
    const ctx = canvas.getContext('2d');
    
    // Draw the background image
    ctx.drawImage(background, 0, 0);
    
    // Draw the 3D text on the canvas
    drawText(ctx, muptime, canvas.width, canvas.height);
    
    // Get the image as a buffer
    const buffer = canvas.toBuffer();

    // Create a captivating caption
    const caption = `${jam}`;

    // Send the image back with the caption
    conn.sendMessage(m.chat, { image: buffer, caption: caption }, { quoted: m });
}

handler.help = ['runtime'];
handler.tags = ['info'];
handler.command = ['runtime', 'rt'];
export default handler;

function clockString(ms) {
    let d = Math.floor(ms / 86400000).toString().padStart(2, '0');
    let h = Math.floor(ms / 3600000) % 24;
    let m = Math.floor(ms / 60000) % 60;

    return `${d}D-${h.toString().padStart(2, '0')}H-${m.toString().padStart(2, '0')}M`;
}

function waktu(ms) {
    let d = Math.floor(ms / (1000 * 60 * 60 * 24));
    let h = Math.floor(ms / (1000 * 60 * 60)) % 24;
    let m = Math.floor(ms / (1000 * 60)) % 60;
    let s = Math.floor(ms / 1000) % 60;
    return `${d} Days ☀️\n${h} Hours 🕐\n${m} Minute ⏰\n${s} Second ⏱️`;
}

function drawText(ctx, text, canvasWidth, canvasHeight) {
    const fontSize = 50;
    ctx.font = `${fontSize}px Arial`;
    ctx.textAlign = 'center';

    const textX = canvasWidth / 2;
    const textY = canvasHeight / 2 + 50;

    const shiftX = 95; // ini buat geser kiri(-) kanan(+)
    const shiftY = -40; // nah ini buat atas(-) bawah(+)

    const finalTextX = textX + shiftX;
    const finalTextY = textY + shiftY;

    ctx.fillStyle = 'rgba(0, 0, 0, 0.6)';
    ctx.fillText(text, finalTextX + 3, finalTextY + 3); // ini buat bayang2 heh
    ctx.fillStyle = 'white';
    ctx.fillText(text, finalTextX, finalTextY);
}