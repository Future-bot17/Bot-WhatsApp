import { cpus, totalmem, freemem, loadavg, uptime, arch, platform, hostname, tmpdir, homedir, type, release, networkInterfaces, userInfo } from "os";
import { performance } from "perf_hooks";
import { runtime } from "../lib/other-function.js";

function customSizeFormatter(options) {
    const { std = "SI", decimalPlaces = 2, keepTrailingZeroes = false } = options || {};

    function render(literal, symbol) {
        return `${literal.toFixed(decimalPlaces)} ${symbol}B`;
    }

    function format(sizeInBytes) {
        const symbols = {
            SI: ["", "K", "M", "G", "T", "P", "E", "Z", "Y"],
            IEC: ["", "Ki", "Mi", "Gi", "Ti", "Pi", "Ei", "Zi", "Yi"],
            JEDEC: ["", "K", "M", "G", "T", "P", "E", "Z", "Y"],
        };

        const base = std.toUpperCase();
        const baseSymbols = symbols[base] || symbols.SI;

        let power = 0;
        let size = sizeInBytes / 1024;

        while (size >= 1 && power < baseSymbols.length - 1) {
            size /= 1024;
            power++;
        }

        const formattedSize = keepTrailingZeroes ? size : parseFloat(size.toFixed(decimalPlaces));
        return render(formattedSize, baseSymbols[power]);
    }

    return format;
}

const format = customSizeFormatter({
    std: "JEDEC", // 'SI' (default) | 'IEC' | 'JEDEC'
    decimalPlaces: 2,
    keepTrailingZeroes: false,
});

const handler = async (m, { conn }) => {
    let pict = `https://telegra.ph/file/082808f1102ed3f797d25.jpg`;
    let cpu = cpus()[0] || "";
    let osUptime = runtime(uptime());
    let runtimeValue = runtime(process.uptime());
    let speed = performance.now() - performance.now();
    let txt = `*Response Speed:* ${speed.toFixed(4)} seconds\n`;
    txt += `*Runtime :* ${runtimeValue}\n`;
    txt += `*OS Uptime :* ${osUptime}\n`;
    txt += `*CPU Model:* ${cpu.model.trim()}\n`; 
    txt += `*CPU Speed:* ${cpu.speed} MHZ\n`;
    txt += `*RAM:* ${format(totalmem() - freemem())} / ${format(totalmem())}\n`;
    txt += `*CPU Cores:* ${cpus().length}\n`;
    txt += `*Arch:* ${arch()}\n`;
    txt += `*Platform:* ${platform()}\n`;
    txt += `*Hostname:* ${hostname()}\n`;
    txt += `*Temp Directory:* ${tmpdir()}\n`;
    txt += `*Home Directory:* ${homedir()}\n`;
    txt += `*OS Type:* ${type()}\n`;
    txt += `*OS Release:* ${release()}\n`;
    txt += `*Load Average:* ${loadavg().join(", ")}\n`;
    txt += `*Network Interfaces:* ${Object.keys(networkInterfaces()).join(", ")}\n`;
    txt += `*User Info:* ${userInfo().username}`;

    conn.reply(m.chat, txt, m);
};

handler.help = ["ping"];
handler.tags = ['main'];
handler.command = /^(p(i|o)ng)$/i;

export default handler;