import axios from 'axios';

async function luminAi(text, user = null, prompt = null, webSearchMode = false, imageBuffer = null) {
    try {
        const data = { content: text }
        if (user) data.user = user
        if (prompt) data.prompt = prompt
        data.webSearchMode = webSearchMode
        data.imageBuffer = imageBuffer

        const { data: res } = await axios.post("https://luminai.my.id", data);
        return res.result;
    } catch (error) {
        console.error('Terjadi kesalahan:', error)
        throw error;
    }
}

let handler = async (m, { text, usedPrefix, command, quoted }) => {
    if (!text) return m.reply("mau nanya apa?")
    m.reply(wait)
    let prompt = `mulai sekarang kamu adalah Cia, setiap kali menjawab kamu selalu menyebutkan namamu Contohnya : cia tidak tau, adalagi yang bisa cia bantu, cia ga tau, dan sebagainya, kamu berbicara dengan sopan dan sering kali memakai emoji setiap menjawab`
    
    try {
        
        if (m.text.toLowerCase().includes("tutup group") || m.text.toLowerCase().includes("tutup grup")) {
    await conn.groupSettingUpdate(m.chat, "announcement");
    const responses = ["Oke, grup telah ditutup. Semoga lebih teratur ya~ 😉", "Pesan diterima, grup sekarang dalam mode ditutup", "Grup telah ditutup, silakan mengikuti aturan yang ada"];
    const reply = responses[Math.floor(Math.random() * responses.length)];
    return m.reply(reply);
}

        if (m.text.toLowerCase().includes("buka group")|| m.text.toLowerCase().includes("buka grup")) {
    await conn.groupSettingUpdate(m.chat, "not_announcement");
    const responses = ["Oke, grup telah dibuka. Ayo kita beraktivitas bersama-sama! 😉", "Grup telah dibuka, ayo kita bersenang-senang bareng", "Layanannya telah dibuka. Mari kita aktifkan kembali grup ini"];
    const reply = responses[Math.floor(Math.random() * responses.length)];
    return m.reply(reply);
}
        
        if (m.quoted) {
            let media = await m.quoted.download()// ini agar mendeteksi ada pesan yg lu reply..hehe(buat pengingat)
            let imageBuffer = Buffer.from(media);
            let response = await luminAi(text, m.sender, prompt, false, imageBuffer);
           
            await m.reply(response)
        } else {
            let response = await luminAi(text, m.sender, prompt, false);
        
            await m.reply(response)
        }
    
    } catch (error) {
        console.error(error.message);
       
    }
}

handler.help = ['openai']
handler.tags = ['ai']
handler.command = /^(ai)$/i
export default handler