import fetch from 'node-fetch'
import axios from 'axios'
import crypto from "crypto";
import {
    FormData,
    Blob
} from 'formdata-node';
import {
    fileTypeFromBuffer
} from 'file-type';
import base64 from 'base64-js';

async function chat(Id, teks, base64Data, userId) {
    try {
        let id = Id, text = teks;
        let json = {
            "messages": [{
                "id": id,
                "content": text,
                "role": "user",
                "data": {
                    "imageBase64": "data:image/jpeg;base64," + base64Data,
                    "fileText": text
                }
            }],
            "id": id,
            "previewToken": null,
            "userId": userId,
            "codeModelMode": true,
            "agentMode": {
                "mode": true,
                "id": "FutureIOPSb3Z",
                "name": "Future"
            },
            "trendingAgentMode": {},
            "isMicMode": false,
            "isChromeExt": false,
            "githubToken": null
        };
        let { data } = await axios.post('https://www.blackbox.ai/api/chat', json);
        
        // Clean the response data
    function cleanData(input) {
        if (typeof input === 'string') {
            return input.replace(/\$@\$.+?\$@\$/gs, '');
        } else if (Array.isArray(input)) {
            return input.map(item => cleanData(item));
        } else if (typeof input === 'object' && input !== null) {
            const cleanedObject = {};
            for (let key in input) {
                if (input.hasOwnProperty(key)) {
                    cleanedObject[key] = cleanData(input[key]);
                }
            }
            return cleanedObject;
        }
        return input;
    }
    
    // Clean the response data
    data = cleanData(data);
        
        return data; 
    } catch (e) {
        return e;
    }
}

async function buffimg(imageBuffer, userId, input) {
    try {
        const {
            ext,
            mime
        } = (await fileTypeFromBuffer(imageBuffer)) || {};
        if (!ext || !mime) return null;
        
        const form = new FormData();
        const blob = new Blob([imageBuffer], {
            type: mime
        });
        form.append('image', blob, 'image.' + ext);
        form.append('fileName', 'image.' + ext);
        form.append('userId', userId);
        
        const response = await fetch("https://www.blackbox.ai/api/upload", {
            method: 'POST',
            body: form,
        });
        
        const datas = await response.json();
        const result = datas.response + "\n#\n" + input;
        
        return result;
    } catch (error) {
        console.error("Error:", error);
        throw error;
    }
}

let handler = async (m, {conn, text, usedPrefix, command}) => {
    let teks;
    if (m.quoted && m.quoted.text) {
        teks = m.quoted.text;
    } else if (text) {
        teks = text;
    } else {
        return m.reply(usedPrefix + command + ' siapa presiden Indonesia');
    }
    
    const userId = crypto.randomUUID();
    
    try {
        react("✅")
        if (m.quoted) {
        let media = await m.quoted.download();
        let Id = m.sender.split('@')[0];
        let bs64 = await base64.fromByteArray(media);
        let img = await buffimg(media, userId, teks);
        let result = await chat(Id, img, bs64, userId);
        
        //await conn.sendFile(m.chat, 'https://telegra.ph/file/bc7cc09e5337a383a675c.jpg', '', result, m);
        conn.sendMessage(m.chat, {
            document: fs.readFileSync("./package.json"),
            mimetype: 'application/zip',
            fileName: `FUTURE-BOT.zip`,
            fileLength: 99999999999999,
            pageCount: 100,
            caption: `${result}`
        }, { quoted: m })
        } else {
      let Id = m.sender.split('@')[0];
      let result = await chat(Id, teks, userId);
      await conn.sendMessage(m.chat, {
            document: fs.readFileSync("./package.json"),
            mimetype: 'application/zip',
            fileName: `FUTURE-BOT.zip`,
            fileLength: 99999999999999,
            pageCount: 100,
            caption: `${result}`
        }, { quoted: m })
    }
        
    } catch (e) {
        throw e;
    }
}

handler.help = ['bb'];
handler.tags = ['ai'];
handler.command = /^(bb)$/i;

export default handler;