import pkg from '@whiskeysockets/baileys';
const {
    WA_DEFAULT_TIMER,
    groupToggleEphemeral
} = pkg;

const options = {
    'on': WA_DEFAULT_TIMER,
    'off': 0,
    '1d': 86400,
    '7d': 604800,
    '90d': 7776000
};

const handler = async (m, {
    conn,
    text,
    usedPrefix,
    isAdmin,
    isOwner,
    command
}) => {
    if (!isAdmin && !isOwner) {
        return m.reply(`*「ADMIN GROUP ONLY」*`);
    }

    const lowercaseText = text.toLowerCase();
    const selectedOption = options[lowercaseText];

    if (selectedOption !== undefined) {
        conn.groupToggleEphemeral(m.chat, selectedOption);
        const response = selectedOption === 0 ? 'dimatikan.' : selectedOption === WA_DEFAULT_TIMER ? 'dinyalakan.' : `diset untuk *${lowercaseText}*`;
        m.reply(`*Ephemeral* berhasil ${response}`);
    } else {
        // Create the sections for the list of options
        let sections = [];
        Object.keys(options).forEach(option => {
            sections.push({
                title: option.charAt(0).toUpperCase() + option.slice(1),
                rows: [{
                    title: `Set ${option}`,
                    description: `Silahkan Pilih Waktunya`,
                    id: `${usedPrefix}${command} ${option}`
                }]
            });
        });

        
        conn.sendList(m.chat, "Pilih opsi timer:", "Pengaturan Timer", sections, "® Future Bot", "", { quoted: m });
    }
};

handler.help = ['settimer'];
handler.tags = ['group'];
handler.command = /^(timer)$/i;

export default handler