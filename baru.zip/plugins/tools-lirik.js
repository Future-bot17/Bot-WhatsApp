import fetch from 'node-fetch'

const handler = async (m, { conn, text, command, usedPrefix }) => {
  if (!text) {
    return m.reply(`Gunakan format ${usedPrefix + command} <judul lagu>\n\n*Contoh :* ${usedPrefix + command} death bed (coffee for your head)`)
  }

  try {
    await react("✅")
    const response = await fetch(`https://widipe.com/lirik?text=${encodeURIComponent(text)}`)
    const lyricData = await response.json()

    if (!lyricData.status || !lyricData.result || !lyricData.result.lyrics) {
      return m.reply("Maaf, lirik lagu tidak ditemukan.")
    }

    const { title, artistName, releasedAt, lyrics, url, thumbnail, image, artistUrl } = lyricData.result

    const fullMessage = `*Judul:* ${title}\n*Artis:* ${artistName}\n*Diterbitkan:* ${releasedAt}\n\n*Lirik:*\n${lyrics}\n\n*Link Lirik:* ${url}`

    // ini buat Kirim gambar thumbnail dengan caption..ni contoh nya ya fullmessage tu caption nya
    await conn.sendMessage(m.chat, { image: { url: thumbnail }, caption: fullMessage }, { quoted: m })

  } catch (error) {
    console.error(error)
    await m.reply("Terjadi kesalahan saat mencari lirik.")
  }
}

handler.help = ['lirik'].map(v => v + ' <judul lagu>')
handler.tags = ['tools']
handler.command = /^lirik$/i
handler.diamond = true

export default handler