import fs from 'fs'
import axios from 'axios'

const handler = async (m, { conn, text, usedPrefix, command }) => {
    let image = m.quoted ? await m.quoted.download() : null
    let prompt = m.quoted ? text : text
    m.reply(wait)
    if (!image) {
        if (!text) throw `Contoh:\n${usedPrefix}${command} Halo?`
        let ouh = await fetch(`https://anabot.my.id/api/ai/geminiAI?prompt=${text}&apikey=AnaBotNajmyW`)
        let gyh = await ouh.json()
        
        conn.sendMessage(m.chat, {
            document: fs.readFileSync("./package.json"),
            mimetype: 'application/zip',
            fileName: `FUTURE-BOT.zip`,
            fileLength: 99999999999999,
            pageCount: 100,
            caption: `${gyh.result}`
        }, { quoted: m })
    } else {
        const json = {
            buffer: image ? image.toString("base64") : null,
            apikey: "Px-KeyPrinzOfc",
            prompt: prompt
        }
        
        const { data } = await axios.post("https://anabot.my.id/api/ai/geminiImage", json)
        
        conn.sendMessage(m.chat, {
            document: fs.readFileSync("./package.json"),
            mimetype: 'application/zip',
            fileName: `FUTURE-BOT.zip`,
            fileLength: 99999999999999,
            pageCount: 100,
            caption: `${data.result}`
        }, { quoted: m })
    }
}

handler.command = /^(gemini)$/i
handler.help = ["gemini"]
handler.tags = ["ai"]
handler.premium = false
handler.limit = 5

export default handler