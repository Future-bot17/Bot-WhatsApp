import axios from "axios";
import * as cheerio from "cheerio";

async function TtDown2(URL) {
  const { data } = await axios.post(
    "https://ttsave.app/download",
    {
      query: URL,
      language_id: "2",
    },
    {
      headers: {
        "Content-Type": "application/json",
      },
    }
  );
  const $ = cheerio.load(data);
  const username = $("div.flex-row > h2").text();
  const account = $("div > a").eq(1).text();
  const desc = $("div > p").text();
  const view = $("div > span").eq(0).text();
  const like = $("div > span").eq(2).text();
  const comment = $("div > span").eq(1).text();
  const savePost = $("div > span").eq(2).text();
  const share = $("div > span").eq(3).text();
  const soundTitle = $("div > span").eq(4).text();
  const photoProfil = $("div.flex > a").attr("href");
  const nowatermark = $("div#button-download-ready > a").eq(0).attr("href");
  const watermark = $("div#button-download-ready > a").eq(1).attr("href");
  const audio = $("div#button-download-ready > a").eq(2).attr("href");
  const res = {
    username,
    account,
    desc,
    view,
    like,
    comment,
    savePost,
    share,
    soundTitle,
    photoProfil,
    audio,
    nowatermark,
    watermark,
  };
  return res;
}
let handler = async (m, { conn, args, usedPrefix, command }) => {
    const msg = `Input link atau reply link yang ingin di download!\n\n*Contoh:*\n${usedPrefix + command} link`;
    
    let text;
    if (args.length >= 1) {
        text = args[0];
    } else if (m.quoted && m.quoted.text) {
        const replyText = m.quoted.text;
        const urlMatches = replyText.match(/https?:\/\/[^\s]+/);
        if (urlMatches && urlMatches.length > 0) {
            text = urlMatches[0];
        } else {
            throw msg;
        }
    } else {
        throw msg;
    }
    
    await m.reply(wait)
    
    const result = await TtDown2(text);
  
    const audioBuffer = await axios.get(result.audio, { responseType: "arraybuffer" });
    const videoBuffer = await axios.get(result.nowatermark, { responseType: "arraybuffer" });
    
    await conn.sendFile(m.chat, videoBuffer.data, "video.mp4", "Video TikTok", m);
    conn.sendMessage(m.chat, { audio: { url: result.audio }, mimetype: "audio/mpeg" });
};
handler.help = ["tiktok","tiktok"].map((a) => a + " *[link]*");
handler.tags = ["download"];
handler.command = /^(tiktok|tt)$/i;

export default handler