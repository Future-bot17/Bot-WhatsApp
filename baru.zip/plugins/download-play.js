import yts from "yt-search";
import axios from "axios";

let handler = async (m, { conn, text, usedPrefix, command }) => {
  if (!text) throw `Example: ${usedPrefix + command} judul lagu`;

  m.reply("Sedang mencari...");

  try {
    let search = await yts(text);
    let anu = search.videos[Math.floor(Math.random() * search.videos.length)];

    let cap = `╭┄┄╸「 PLAY SEARCH 」
│❒ ᴛɪᴛʟᴇ : ${anu.title}
│❒ ᴠɪᴇᴡs : ${anu.views}
│❒ ʟɪɴᴋ : ${anu.url}
╰┈┈┈┈┈╸

sᴇᴅᴀɴɢ ᴅɪ ᴘʀᴏsᴇs... 
01:00 ━●─────── ${anu.timestamp}
⇆ㅤ ㅤ◁ㅤ ❚❚ ㅤ▷ ㅤㅤ↻﻿`;

    m.reply(cap);

    // API call to download audio
    const apiUrl = `https://api.ryzendesu.vip/api/downloader/ytmp3?url=${encodeURIComponent(anu.url)}`;
    const response = await axios.get(apiUrl);
    const downloadLink = response.data.url; // Get the URL directly from the response

    conn.sendMessage(m.chat, { audio: { url: downloadLink }, mimetype: 'audio/mpeg' }, { quoted: m });
  } catch (error) {
    console.error(error);
    m.reply('Terjadi kesalahan saat memproses permintaan. Silakan coba lagi.');
  }
};

handler.help = ['play'];
handler.tags = ['download'];
handler.command = ['song', 'play'];
handler.limit = true;

export default handler