const handler = async (m, { conn, text, participants }) => {
  let groupId = m.chat;
  // coded by elkaff, don't delete wm bitch
  let member = participants.map(i => i.id);

  let teks = `${text ? text : ''}\n@${groupId}`;

  await conn.sendMessage(groupId, {
    text: teks,
    contextInfo: {
      mentionedJid: member,
      groupMentions: [
        {
          groupSubject: "everyone",
          groupJid: groupId
        }
      ]
    },
    quoted: m
  });
}

handler.help = ['tagall <pesan>']
handler.tags = ['group']
handler.command = /^(tagall)$/i
handler.group = true
handler.admin = true
export default handler;