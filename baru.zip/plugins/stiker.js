import fs from 'fs'

let handler = async (m, { conn, command, usedPrefix }) => {
  let q = m.quoted ? m.quoted : m
  let mime = (q.msg || q).mimetype || ''
  
  if (/image/.test(mime)) {
    let media = await q.download()
    m.reply(wait)
    let encmedia = await conn.sendImageAsSticker(m.chat, media, m, { packname: global.stickpack, namebot: global.namebot })
    if (encmedia) {
      await fs.unlinkSync(encmedia)
    }
  } else if (/video/.test(mime)) {
    if ((q.msg || q).seconds > 7) return m.reply('maksimal 6 detik!')
    let media = await q.download()
    m.reply(stiker_wait)
    let encmedia = await conn.sendVideoAsSticker(m.chat, media, m, { packname: global.stickpack, namebot: global.namebot })
    if (encmedia) {
      await fs.unlinkSync(encmedia)
    }
  } else {
    throw `Kirim Gambar/Video Dengan Caption ${usedPrefix + command}\nDurasi Video 1-6 Detik`
  }
}

handler.help = ['stiker']
handler.tags = ['stiker']
handler.command = /^(stiker|s)$/i
handler.limit = false

export default handler