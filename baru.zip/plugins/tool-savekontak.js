let handler = async (m, { conn, args }) => {
    let who = m.mentionedJid && m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : m.sender;
    let pp = await conn.profilePictureUrl(who,'image').catch((_) => "https://telegra.ph/file/1ecdb5a0aee62ef17d7fc.jpg");
    let username = conn.getName(who);

    await conn.sendContact(m.chat, [[`${who.split('@')[0]}@s.whatsapp.net`, `${username}`]], m, {
        contextInfo: {
            externalAdReply: {
                title: username,
                body: 'SAVE CONTACT',
                thumbnailUrl: pp,
                sourceUrl: 'https://rikky.com',
                mediaType: 1,
                showAdAttribution: true,
                renderLargerThumbnail: true
            }
        }
    });
};

handler.command = ['savecontact', 'save'];
handler.group = true
handler.admin = true
handler.botAdmin = true

export default handler