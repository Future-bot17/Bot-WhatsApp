import axios from 'axios'
import moment from 'moment-timezone'

const { proto, prepareWAMessageMedia, generateWAMessageFromContent, generateWAMessageContent } = (await import('@whiskeysockets/baileys')).default

let handler = m => m

handler.all = async function (m) {
	
  global.loading = async function loading() {
    var arr = ['🕒', '🕓', '🕔', '🕕', '🕖', '🕗', '🕘', '🕙', '🕚', '🕛',
      `ʟᴏᴀᴅɪɴɢ sᴜᴄᴄᴇssғᴜʟ`]
    
    let load = await conn.sendMessage(m.chat, { text: 'OK' }, { quoted: m })
    
    for (let i = 0; i < arr.length; i++) {
      await new Promise(resolve => setTimeout(resolve, 200))
      await conn.sendMessage(m.chat, { text: arr[i], edit: load.key }, { quoted: m })
    }
  }
//reaksi
global.react = function(text) {
    return conn.sendMessage(m.chat, {
        react: {
            text,
            key: m.key
        }
    })
}

}

export default handler