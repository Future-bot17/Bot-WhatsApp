import fetch from 'node-fetch'

let handler = async (m, { conn }) => {
    let url = gamanaufal[Math.floor(Math.random() * gamanaufal.length)];
    let kataanine = pickRandom(global.kataanine);
    let cap = `Note:\n${kataanine}\nFutureBot`;
    conn.sendMessage(m.chat, { image: { url: url }, caption: `*TERIMAKASIH*\n\n${cap}` }, { quoted: m });
};

handler.command = /^(qris)$/i;
handler.help = ['qris'];
handler.limit = false;
handler.owner = false;
export default handler;

global.gamanaufal = [
    'https://telegra.ph/file/879c7127f7110bd7c449b.jpg',
];

global.kataanine = [
    "*SILAHKAN SCAN QRIS INI UNTUK MELANJUTKAN PEMBAYARAN*"
];

function pickRandom(list) {
    return list[Math.floor(Math.random() * list.length)];
}