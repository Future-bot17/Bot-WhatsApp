import axios from "axios";
import * as cheerio from "cheerio";

async function indown(urls) {
  try {
    const url = "https://indown.io/id";
    const options = { withCredentials: true };
    const {
      data: html,
      headers,
    } = await axios.get(url, options);

    const cookies = headers["set-cookie"].join("; ");
    const $ = cheerio.load(html);
    const formAction = $("form#downloadForm").attr("action");
    const inputElements = $("form#downloadForm input[name]").get();
    const inputValues = Object.fromEntries(
      inputElements.map((element) => [
        $(element).attr("name"),
        $(element).val() || "",
      ])
    );

    inputValues.link = urls;

    const postOptions = {
      headers: {
        "Content-Type": "application/x-www-form-urlencoded",
        Cookie: cookies,
      },
      withCredentials: true,
    };
    const {
      data: responseData,
    } = await axios.post(formAction, new URLSearchParams(inputValues), postOptions);

    const $$ = cheerio.load(responseData);
    const mediaSet = new Set();

    $$("div.container.mt-4#result div.row.justify-content-center div.col-md-4").map(
      (_, el) => {
        const mediaLink = $$($$(el));
        const type = mediaLink.find("a.image-link").length > 0 ? "image" : "video";
        const href =
          decodeURIComponent(
            $$(type === "image" ? "div > div > div.mt-3 > a" : "#result > div > div > div.mt-3 > div > a.mb-2").attr(
              "href"
            )
          ) || "";
        const alternative =
          mediaLink.find(type === "image" ? "a.image-link" : "div.mt-3 > div > a").attr("href") || "";

        mediaSet.add({
          type: type,
          href: href,
          alternative: alternative,
        });
      }
    );

    return [...mediaSet];
  } catch (error) {
    console.error("Error:", error);
    throw error;
  }
}

export { indown }