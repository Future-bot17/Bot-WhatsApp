import { smsg } from "./lib/simple.js"
import { format } from "util"
import { fileURLToPath } from "url"
import path, { join } from "path"
import fs, { unwatchFile, watchFile, readFileSync } from "fs"
import chalk from "chalk"
import fetch from "node-fetch"
import axios from "axios"
const cheerio = (await import("cheerio")).default;
//import cheerio from "cheerio"
import got from "got"
import qs from "qs"
import FormData from "form-data"
const baileys = await (await import('@whiskeysockets/baileys'))

const isNumber = x => typeof x === "number" && !isNaN(x)
const delay = ms => isNumber(ms) && new Promise(resolve => setTimeout(function() {
    clearTimeout(this)
    resolve()
}, ms))

const { getAggregateVotesInPollMessage, makeInMemoryStore } = await (await import('@whiskeysockets/baileys')).default;
import Pino from "pino"
const store = makeInMemoryStore({
    logger: Pino().child({
        level: 'fatal',
        stream: 'store'
    })
})
const readMore = String.fromCharCode(8206).repeat(4001);
const form = FormData()
async function formatMoney(number) {
  const formattedRubel = number.toLocaleString('ru-RU', { style: 'currency', currency: 'RUB' });
  return formattedRubel.replace("₽", "Pxr")
};
async function toRupiah(angka) {
  var saldo = "";
  var angkarev = angka.toString().split("").reverse().join("");
  for (var i = 0; i < angkarev.length; i++)
    if (i % 3 == 0) saldo += angkarev.substr(i, 3) + ".";
  return ("" + saldo.split("", saldo.length - 1).reverse().join(""));
}
export async function handler(chatUpdate) {
    this.functions = this.functions || {}
    this.functions.axios = axios;
    this.functions.baileys = baileys;
    this.functions.cheerio = cheerio;
    this.functions.delay = delay;
    this.functions.fetch = fetch;
    this.functions.form = form;
    this.functions.fs = fs;
    this.functions.got = got;
    this.functions.qs = qs;
    this.functions.formatMoney = formatMoney;
    this.functions.toRupiah = toRupiah;
    this.msgqueque = this.msgqueque || []
    if (!chatUpdate)
        return
    this.pushMessage(chatUpdate.messages).catch(console.error)
    let m = chatUpdate.messages[chatUpdate.messages.length - 1]
    if (!m)
        return
    if (m.message?.viewOnceMessageV2) m.message = m.message.viewOnceMessageV2.message
	if (m.message?.documentWithCaptionMessage) m.message = m.message.documentWithCaptionMessage.message
	if (m.message?.viewOnceMessageV2Extension) m.message = m.message.viewOnceMessageV2Extension.message
    if (global.db.data == null)
        await global.loadDatabase()
    try {
        m = smsg(this, m) || m
        if (!m)
            return
        m.exp = 0
        m.limit = false
        global.Functs = this.functions;
        try {
            if (m.mtype === "interactiveResponseMessage" && m.quoted.fromMe) conn.appenTextMessage(m, JSON.parse(m.msg.nativeFlowResponseMessage.paramsJson).id, chatUpdate) 
            if (m.mtype === "templateButtonReplyMessage" && m.quoted.fromMe) conn.appenTextMessage(m, m.msg.selectedId, chatUpdate)
            // TODO: use loop to insert data instead of this
            let user = global.db.data.users[m.sender]
            if (typeof user !== "object")
                global.db.data.users[m.sender] = {}
            if (user) {
                if (!("registered" in user)) user.registered = false
                if (!user.registered) {
                    if (!("name" in user)) user.name = m.name
                    if (!isNumber(user.age)) user.age = -1
                    if (!isNumber(user.regTime)) user.regTime = -1
                }
                if (!isNumber(user.afk)) user.afk = -1
                if (!isNumber(user.level)) user.level = 0
                if (!isNumber(user.limit)) user.limit = 10
                if (!isNumber(user.money)) user.money = 0
                if (!isNumber(user.bank)) user.bank = 0
                if (!user.premium) user.premium = false
                if (!user.premiumTime) user.premiumTime = 0
            }
            let chat = global.db.data.chats[m.chat]
            if (typeof chat !== "object")
                global.db.data.chats[m.chat] = {}
            if (chat) {
                if (!("autolevelup" in chat)) chat.autolevelup = false
                if (!("mute" in chat)) chat.mute = false
                if (!("nsfw" in chat)) chat.nsfw = false
                if (!("games" in chat)) chat.games = false
                if (!("premium" in chat)) chat.premium = false
                if (!("premiumTime" in chat)) chat.premiumTime = false
                if (!("premnsfw" in chat)) chat.premnsfw = false
                if (!("sBye" in chat)) chat.sBye = ""
                if (!("sDemote" in chat)) chat.sDemote = ""
                if (!("sPromote" in chat)) chat.sPromote = ""
                if (!("sWelcome" in chat)) chat.sWelcome = ""
                if (!("viewOnce" in chat)) chat.viewOnce = false
                if (!("welcome" in chat)) chat.welcome = true
            }
            let settings = global.db.data.settings[this.user.jid]
            if (typeof settings !== "object") global.db.data.settings[this.user.jid] = {}
            if (settings) {
                if (!("self" in settings)) settings.self = false
                if (!("pconly" in settings)) settings.pconly = false
                if (!("gconly" in settings)) settings.gconly = false
                if (!("maintenance" in settings)) settings.maintenance = false
                if (!("autoread" in settings)) settings.autoread = true
                if (!("restrict" in settings)) settings.restrict = false
                if (!("autorestart" in settings)) settings.autorestart = true
                if (!("antiCall" in settings)) settings.antiCall = true
                if (!("restartDB" in settings)) settings.restartDB = 0
                if (!("voucherList" in settings)) settings.voucherList = {}
                if (!("lastNotify" in settings)) settings.lastNotify = {}
            }
        } catch (e) {
            console.error(e)
        }
        if (typeof m.text !== "string")
            m.text = ""

        const isROwner = [conn.decodeJid(global.conn.user.id), ...global.owner.map(([number]) => number)].map(v => v.replace(/[^0-9]/g, "") + "@s.whatsapp.net").includes(m.sender)
        const isOwner = isROwner || m.fromMe
        const isMods = isOwner || global.mods.map(v => v.replace(/[^0-9]/g, "") + "@s.whatsapp.net").includes(m.sender)
        const isPrems = isROwner || db.data.users[m.sender].premiumTime > 0

        if (opts["queque"] && m.text && !(isMods || isPrems)) {
            let queque = this.msgqueque,
                time = 1000 * 5
            const previousID = queque[queque.length - 1]
            queque.push(m.id || m.key.id)
            setInterval(async function() {
                if (queque.indexOf(previousID) === -1) clearInterval(this)
                await delay(time)
            }, time)
        }

        if (m.isBaileys)
            return
        //m.exp += Math.floor(Math.random() * 5)

        let usedPrefix
        let _user = global.db.data && global.db.data.users && global.db.data.users[m.sender]

        const groupMetadata = (m.isGroup ? ((conn.chats[m.chat] || {}).metadata || await this.groupMetadata(m.chat).catch(_ => null)) : {}) || {}
        const participants = (m.isGroup ? groupMetadata.participants : []) || []
        const user = (m.isGroup ? participants.find(u => conn.decodeJid(u.id) === m.sender) : {}) || {} // User Data
        const bot = (m.isGroup ? participants.find(u => conn.decodeJid(u.id) == conn.user.jid) : {}) || {} // Your Data
        const isRAdmin = user?.admin == "superadmin" || false
        const isAdmin = isRAdmin || user?.admin == "admin" || false // Is User Admin?
        const isBotAdmin = bot?.admin || false // Are you Admin?

        const ___dirname = path.join(path.dirname(fileURLToPath(import.meta.url)), "./plugins")
        for (let name in global.plugins) {
            let plugin = global.plugins[name]
            if (!plugin)
                continue
            if (plugin.disabled)
                continue
            const __filename = join(___dirname, name)
            if (typeof plugin.all === "function") {
                try {
                    await plugin.all.call(this, m, {
                        chatUpdate,
                        __dirname: ___dirname,
                        __filename
                    })
                } catch (e) {
                    // if (typeof e === "string") continue
                    console.error(e)
                    for (let [jid] of global.owner.filter(([number, _, isDeveloper]) => isDeveloper && number)) {
                        let data = (await conn.onWhatsApp(jid))[0] || {}
                        if (data.exists)
                            m.reply(`*🗂️ Plugin:* ${name}\n*👤 Sender:* ${m.sender}\n*💬 Chat:* ${m.chat}\n*💻 Command:* ${m.text}\n\n\${format(e)}`.trim(), data.jid)
                    }
                }
            }
            if (!opts["restrict"])
                if (plugin.tags && plugin.tags.includes("admin")) {
                    continue
                }
            const str2Regex = str => str.replace(/[|\\{}()[\]^$+*?.]/g, "\\$&")
            let _prefix = plugin.customPrefix ? plugin.customPrefix : global.prefix ? global.prefix : ''
            let match = (_prefix instanceof RegExp ? // RegExp Mode?
                [
                    [_prefix.exec(m.text), _prefix]
                ] :
                Array.isArray(_prefix) ? // Array?
                _prefix.map(p => {
                    let re = p instanceof RegExp ? // RegExp in Array?
                        p :
                        new RegExp(str2Regex(p))
                    return [re.exec(m.text), re]
                }) :
                typeof _prefix === "string" ? // String?
                [
                    [new RegExp(str2Regex(_prefix)).exec(m.text), new RegExp(str2Regex(_prefix))]
                ] : [
                    [
                        [], new RegExp
                    ]
                ]
            ).find(p => p[1])
            if (typeof plugin.before === "function") {
                if (await plugin.before.call(this, m, {
                        match,
                        conn: this,
                        participants,
                        groupMetadata,
                        user,
                        bot,
                        isROwner,
                        isOwner,
                        isRAdmin,
                        isAdmin,
                        isBotAdmin,
                        isPrems,
                        chatUpdate,
                        __dirname: ___dirname,
                        __filename
                    }))
                    continue
            }
            if (typeof plugin !== "function")
                continue
            if ((usedPrefix = (match[0] || "")[0])) {
                let noPrefix = m.text.replace(usedPrefix, "")
                let [command, ...args] = noPrefix.trim().split` `.filter(v => v)
                args = args || []
                let _args = noPrefix.trim().split` `.slice(1)
                let text = _args.join` `
                command = (command || "").toLowerCase()
                let fail = plugin.fail || global.dfail // When failed
                let isAccept = plugin.command instanceof RegExp ? // RegExp Mode?
                    plugin.command.test(command) :
                    Array.isArray(plugin.command) ? // Array?
                    plugin.command.some(cmd => cmd instanceof RegExp ? // RegExp in Array?
                        cmd.test(command) :
                        cmd === command
                    ) :
                    typeof plugin.command === "string" ? // String?
                    plugin.command === command :
                    ''

                if (!isAccept)
                    continue
                m.plugin = name
                if (m.chat in global.db.data.chats || m.sender in global.db.data.users || this.user.jid in global.db.data.settings) {
                    let chat = global.db.data.chats[m.chat]
                    let user = global.db.data.users[m.sender]
                    let settings = global.db.data.settings[this.user.jid]
                    if (name != "owner-unbannedchat.js" && chat?.isBanned)
                        return // Except this
                    if (name != "owner-unbanneduser.js" && user?.banned)
                        return
                    //if (name != "game-suitpvp_ans.js" && settings?.gconly)
                        //return
                }
                if (global.db.data.chats[m.chat].mute === true && !(isAdmin || isROwner)) return
                if (global.db.data.settings[this.user.jid].gconly === true && !m.chat.endsWith("g.us") && (name != "game-suitpvp_ans.js" && name != "game-werewolfpc.js")) return
                if (global.db.data.settings[this.user.jid].pconly === true && m.chat.endsWith("g.us")) return
                if (global.db.data.settings[this.user.jid].maintenance && !(isROwner || isOwner)) { // Both Maintenance
                    fail("maintenance", m, this)
                    continue
                }
                if (plugin.rowner && plugin.owner && !(isROwner || isOwner)) { // Both Owner 
                    fail("owner", m, this)
                    continue
                }
                if (plugin.rowner && !isROwner) { // Real Owner
                    fail("owner", m, this)
                    continue
                }
                if (plugin.owner && !isOwner) { // Number Owner
                    fail("owner", m, this)
                    continue
                }
                if (plugin.mods && !isMods) { // Moderator
                    fail("mods", m, this)
                    continue
                }
                if (plugin.premium && !isPrems) { // Premium
                    fail("premium", m, this)
                    continue
                }
                if (plugin.group && !m.isGroup) { // Group Only
                    fail("group", m, this)
                    continue
                }
                if (plugin.botAdmin && !(isBotAdmin || isROwner)) { // You Admin
                    fail("botAdmin", m, this)
                    continue
                }
                if (plugin.admin && !(isAdmin || isROwner)) { // User Admin
                    fail("admin", m, this)
                    continue
                }
                if (plugin.private && m.isGroup) { // Private Chat Only
                    fail("private", m, this)
                    continue
                }
                if (plugin.register == true && _user.registered == false) { // Butuh daftar?
                    fail("unreg", m, this)
                    continue
                }
                if (plugin.testingStage && !(isROwner || isOwner)) { // Both Owner 
                    fail("testingStage", m, this)
                    continue
                }
                m.isCommand = true
                let xp = "exp" in plugin ? parseInt(plugin.exp) : Math.floor(Math.random() * 5) // XP Earning per command
                if (xp > 200)
                    this.sendMessage(m.chat, {
                        text: `*It looks like you're cheating, using a calculator*`,
                        mentions: [m.sender]
                    }, {
                        quoted: m
                    })
                else
                    m.exp += xp
                if (!isPrems && plugin.limit && global.db.data.users[m.sender].limit < plugin.limit * 1) {
                    this.sendMessage(m.chat, {
                        text: `_Your limit runs out, buy by *.buylimit <jumlah>*_ `,
                        mentions: [m.sender]
                    }, {
                        quoted: m
                    })
                    continue // Limit habis
                }
                if (plugin.level > _user.level) {
                    this.sendMessage(m.chat, {
                        text: `Level *${plugin.level}* is required to use this command. Your level *${_user.level}*\n*${plugin.level}* level is required to use this command. Your level is *${_user.level}*`,
                        mentions: [m.sender]
                    }, {
                        quoted: m
                    })
                    continue // If the level has not been reached
                }
                let extra = {
                    match,
                    usedPrefix,
                    noPrefix,
                    _args,
                    args,
                    command,
                    text,
                    conn: this,
                    participants,
                    groupMetadata,
                    user,
                    bot,
                    isROwner,
                    isOwner,
                    isRAdmin,
                    isAdmin,
                    isBotAdmin,
                    isPrems,
                    chatUpdate,
                    __dirname: ___dirname,
                    __filename
                }
                try {
                    await plugin.call(this, m, extra)
                    if (!isPrems)
                        m.limit = m.limit || plugin.limit || false
                } catch (e) {
                    // Error occured
                    m.error = e
                    console.error(e)
                    if (e) {
                        let text = format(e)
                        for (let key of Object.values(global.APIKeys))
                            text = text.replace(new RegExp(key, "g"), "#HIDDEN#")
                        if (e.name)
                            for (let [jid] of global.owner.filter(([number, _, isDeveloper]) => isDeveloper && number)) {
                                let data = (await this.onWhatsApp(jid))[0] || {}
                                if (data.exists)
                                    return m.reply(`*🗂️ Plugin:* ${m.plugin}\n*👤 Sender:* ${m.sender}\n*💬 Chat:* ${m.chat}\n*💻 Command:* ${usedPrefix}${command} ${args.join(" ")}\n📄 *Error Logs:*\n\n${text}`.trim(), data.jid)
                            }
                        m.reply(text)
                    }
                } finally {
                    // m.reply(util.format(_user))
                    if (typeof plugin.after === "function") {
                        try {
                            await plugin.after.call(this, m, extra)
                        } catch (e) {
                            console.error(e)
                        }
                    }
                    if (m.limit)
                        console.log(+m.limit + ` Limit terpakai!\n${global.db.data.users[m.sender].limit -m.limit} Limit tersisa.`)
                }
                break
            }
        }
    } catch (e) {
        console.error(e)
    } finally {
        if (opts["queque"] && m.text) {
            const quequeIndex = this.msgqueque.indexOf(m.id || m.key.id)
            if (quequeIndex !== -1)
                this.msgqueque.splice(quequeIndex, 1)
        }
        let user, stats = global.db.data.stats
        if (m) {
            if (m.sender && (user = global.db.data.users[m.sender])) {
                user.exp += m.exp
                user.limit -= m.limit * 1
            }

            let stat
            if (m.plugin) {
                let now = +new Date
                if (m.plugin in stats) {
                    stat = stats[m.plugin]
                    if (!isNumber(stat.total))
                        stat.total = 1
                    if (!isNumber(stat.success))
                        stat.success = m.error != null ? 0 : 1
                    if (!isNumber(stat.last))
                        stat.last = now
                    if (!isNumber(stat.lastSuccess))
                        stat.lastSuccess = m.error != null ? 0 : now
                } else
                    stat = stats[m.plugin] = {
                        total: 1,
                        success: m.error != null ? 0 : 1,
                        last: now,
                        lastSuccess: m.error != null ? 0 : now
                    }
                stat.total += 1
                stat.last = now
                if (m.error == null) {
                    stat.success += 1
                    stat.lastSuccess = now
                }
            }
        }

        try {
            if (!opts["noprint"]) await (await import("./lib/print.js")).default(m, this)
        } catch (e) {
            console.log(m, m.quoted, e)
        }
        if (global.db.data.settings[this.user.jid].autoread)
            await this.chatRead(m.key).catch(() => {})
    }
}

export async function participantsUpdate({
    id,
    participants,
    action
}) {
    if (opts["self"] || this.isInit) return;
    if (global.db.data == null) await loadDatabase();
    const chat = global.db.data.chats[id] || {};
    switch (action) {
        case "add":
        case "remove":
            if (chat.welcome) {
                const groupMetadata = await this.groupMetadata(id) || (this.chats[id] || {}).metadata;
                for (let user of participants) {
                    const isAddAction = action === "add";
                    const welcomeText = isAddAction ? (chat.sWelcome || this.welcome || conn.welcome || `Selamat datang, @user!`).replace("@subject", await this.getName(id)).replace("@desc", groupMetadata.desc?.toString() || "tidak diketahui") :
                        (chat.sBye || this.bye || conn.bye || `Sampai jumpa, @user!`);
                    await this.reply(id, welcomeText.replace("@user", "@" + user.split("@")[0]), null, {
                        mentions: [user]
                    });
                }
            }
            break;
        case "promote":
            const promoteText = (chat.sPromote || this.spromote || conn.spromote || `@user *telah diangkat menjadi Admin*`).replace("@user", "@" + participants[0].split("@")[0]);
            if (chat.detect) {
                this.sendMessage(id, {
                    text: promoteText.trim(),
                    mentions: [participants[0]]
                }, {
                    quoted: null
                });
            }
            break;
        case "demote":
            const demoteText = (chat.sDemote || this.sdemote || conn.sdemote || `@user *tidak lagi menjadi Admin*`).replace("@user", "@" + participants[0].split("@")[0]);
            if (chat.detect) {
                this.sendMessage(id, {
                    text: demoteText.trim(),
                    mentions: [participants[0]]
                }, {
                    quoted: null
                });
            }
            break;
    }
}

export async function groupsUpdate(groupsUpdate) {
    if (opts["self"]) return
    for (const groupUpdate of groupsUpdate) {
        const id = groupUpdate.id
        if (!id) continue
        let chats = global.db.data.chats[id] || {}
        let text = ""
        if (!chats.detect) continue

        if (groupUpdate.desc) {
            text = (chats.sDesc || this.sDesc || conn.sDesc || `*Deskripsi telah diubah menjadi*\n@desc`)
                .replace("@desc", groupUpdate.desc)
        } else if (groupUpdate.subject) {
            text = (chats.sSubject || this.sSubject || conn.sSubject || `*Subjek telah diubah menjadi*\n@subject`)
                .replace("@subject", groupUpdate.subject)
        } else if (groupUpdate.icon) {
            text = (chats.sIcon || this.sIcon || conn.sIcon || `*Icon telah diubah menjadi*`)
                .replace("@icon", groupUpdate.icon)
        } else if (groupUpdate.revoke) {
            text = (chats.sRevoke || this.sRevoke || conn.sRevoke || `*Tautan grup telah diubah menjadi*\n@revoke`)
                .replace("@revoke", groupUpdate.revoke)
        } else if (groupUpdate.announce === true) {
            text = (chats.sAnnounceOn || this.sAnnounceOn || conn.sAnnounceOn || `*Grup telah ditutup!*`)
        } else if (groupUpdate.announce === false) {
            text = (chats.sAnnounceOff || this.sAnnounceOff || conn.sAnnounceOff || `*Grup telah dibuka!*`)
        } else if (groupUpdate.restrict === true) {
            text = (chats.sRestrictOn || this.sRestrictOn || conn.sRestrictOn || `*Grup telah dibatasi hanya untuk peserta!*`)
        } else if (groupUpdate.restrict === false) {
            text = (chats.sRestrictOff || this.sRestrictOff || conn.sRestrictOff || `*Grup telah dibatasi hanya untuk admin!*`)
        }

        if (!text) continue
        this.sendMessage(id, {
            text: text.trim(),
            mentions: []
        }, {
            quoted: null
        })
    }
}

export async function deleteUpdate(message) {
    try {
        const {
            fromMe,
            id,
            participant
        } = message
        if (fromMe)
            return
        let msg = this.serializeM(this.loadMessage(id))
        if (!msg)
            return
        let chat = global.db.data.chats[msg.chat] || {}
        if (!chat.antiDelete)
            return
        this.sendMessage(msg.key.remoteJid, {
            text: `❗ Terdeteksi @${participant.split`@`[0]} telah menghapus pesan.\nUntuk mematikan fitur ini, ketik\n*.off antidelete*\n\nUntuk menghapus pesan yang dikirim BOT, reply pesan dengan perintah\n*.delete*`,
            mentions: [participant]
        }, {
            quoted: msg
        })
        this.copyNForward(msg.chat, msg, false).catch(e => console.log(e, msg))
    } catch (e) {
        console.error(e)
    }
}

// respon cmd pollMessage
async function getMessage(key){
    if (store) {
        const msg = await store.loadMessage(key.remoteJid, key.id)
        return msg?.message
    }
    return {
        conversation: "Hai Im PX - Bot"
    }
}

export async function pollUpdate(message) {
    for (const { key, update } of message) {
        if (update.pollUpdates && key.fromMe) {
            const pollCreation = await getMessage(key)
            if (pollCreation) {
                const pollUpdate = await getAggregateVotesInPollMessage({
                    message: pollCreation,
                    pollUpdates: pollCreation.pollUpdates,
                })
                conn.logger.info(pollMessage)
                var toCmd = pollUpdate.filter(v => v.voters.length !== 0)[0]?.name
	            if (toCmd == undefined) return
	            conn.logger.info(toCmd)
                var prefCmd = global.prefix+toCmd
	            conn.appenTextMessage(m, prefCmd, chatUpdate)
            }
        }
    }
}

function getLocalTime(timestamp) {
    const currentDate = new Date(timestamp);
    const options = {
        timeZone: 'Asia/Jakarta',
        hour: 'numeric',
        minute: 'numeric',
        weekday: 'long',
        month: 'long',
        day: 'numeric',
        year: 'numeric'
    };
    return currentDate.toLocaleString('id-ID', options);
}

export async function presenceUpdate(presenceUpdate) {
  const id = presenceUpdate.id;
  const nouser = Object.keys(presenceUpdate.presences);
  const status = presenceUpdate.presences[nouser[0]]?.lastKnownPresence;
  const user = global.db.data.users[nouser[0]];
  if (user?.afk && (status === "composing" || status === "recording") && user.afk > -1) {
    if (user.banned) {
      user.afk = -1;
      user.afkReason = "User Banned Afk";
      return;
    }
    const username = nouser[0].split("@")[0];
    const localTime = getLocalTime(user.afk);
    const afkTime = user.afk;
    const caption = `*@${username} Have returned from Afk*

 ${htjava} *Detect:* ${status === "composing" ? "Typing" : "Recording"}
 ${htjava} *Reason:* ${user.afkReason ? user.afkReason : 'No Reason'}
 ${htjava} *During:* ${(new Date - afkTime).toTimeString()}
 ${htjava} *Since:* ${localTime}`;

    this.reply(id, caption, null, {
        mentions: [nouser[0]]
    });
    user.afk = -1;
    user.afkReason = "";
  }
}

global.dfail = (type, m, conn) => {
  const userTag = `Hai *@${m.sender.split("@")[0]}*, `;
  const msg = {
    owner: `*[ Akses Ditolak ]*\n\n${userTag} Perintah ini hanya dapat digunakan oleh Owner Bot!`,
    maintenance: `*[ Akses Ditolak ]*\n\n${userTag} PX - Bot sedang menjalani perawatan. Selama perawatan, bot tidak dapat digunakan!`,
    premium: `*[ Akses Ditolak ]*\n\n${userTag} Perintah ini hanya untuk member *Premium*!`,
    group: `*[ Akses Ditolak ]*\n\n${userTag} Perintah ini hanya dapat digunakan di grup!`,
    private: `*[ Akses Ditolak ]*\n\n${userTag} Perintah ini hanya dapat digunakan di Chat Pribadi!`,
    admin: `*[ Akses Ditolak ]*\n\n${userTag} Perintah ini hanya untuk *Admin* grup!`,
    botAdmin: `*[ Akses Ditolak ]*\n\n${userTag} Jadikan bot sebagai Admin untuk menggunakan perintah ini!`,
    unreg: `*[ Akses Ditolak ]*\n\n${userTag} Lakukan registrasi terlebih dahulu untuk menggunakan bot.\nBagaimana cara registrasi?\n\n*Contoh:* .register PrinzXz~18`,
    nsfw: `*[ Akses Ditolak ]*\n\n${userTag} NSFW tidak aktif, harap hubungi Tim Diskusi Bot untuk mengaktifkan fitur ini!`,
    games: `*[ Akses Ditolak ]*\n\n${userTag} Anda harus bergabung ke grup resmi PrinzXz terlebih dahulu untuk memainkan permainan!\n\nKetik *.officialgroup* untuk melihat informasi grup PrinzXz`,
    roleplay: `*[ Akses Ditolak ]*\n\n${userTag} Anda harus bergabung ke grup resmi PrinzXz terlebih dahulu untuk memainkan permainan!\n\nKetik *.officialgroup* untuk melihat informasi grup PrinzXz`,
    restrict: `*[ Akses Ditolak ]*\n\n${userTag} Fitur ini *dinonaktifkan*!`,
    testingStage: `*[ Akses Ditolak ]*\n\n${userTag} Fitur ini belum dibuka atau masih dalam tahap pengembangan!`,
  }[type];
  if (msg)
    return conn.sendMessage(m.chat, {
      text: msg,
      mentions: conn.parseMention(msg),
    }, {
      quoted: m,
    });
};

let file = global.__filename(import.meta.url, true)
watchFile(file, async () => {
    unwatchFile(file)
    console.log(chalk.redBright("Update handler.js"))
    if (global.reloadHandler) console.log(await global.reloadHandler())
})